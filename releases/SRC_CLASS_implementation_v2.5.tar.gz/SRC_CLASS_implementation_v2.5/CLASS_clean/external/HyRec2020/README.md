# HYREC-2
By Yacine Ali-Haimoud and Chris Hirata (2010-17)
	with contributions from Nanoom Lee (2020).

Version July 2020.

See readme.pdf for detailed info.
